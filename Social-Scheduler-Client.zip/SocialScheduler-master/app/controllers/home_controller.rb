class HomeController < ApplicationController

	def tour_url_add
	end

	def tour_url_complete
		a = TourUrls.new
		a.tour_name = params[:name]
		a.tour_url = params[:url1]
	 	b = TourUrls.new
		b.tour_name = params[:name]
		b.tour_url = params[:url2]
	 	c = TourUrls.new
		c.tour_name = params[:name]
		c.tour_url = params[:url3]
	 	d = TourUrls.new
		d.tour_name = params[:name]
		d.tour_url = params[:url4]
	 	e = TourUrls.new
		e.tour_name = params[:name]
		e.tour_url = params[:url5]
	 	f = TourUrls.new
		f.tour_name = params[:name]
		f.tour_url = params[:url6]
	 	g = TourUrls.new
		g.tour_name = params[:name]
		g.tour_url = params[:url7]
	 	h = TourUrls.new
		h.tour_name = params[:name]
		h.tour_url = params[:url8]
	 	i = TourUrls.new
		i.tour_name = params[:name]
		i.tour_url = params[:url9]

		a.save
		b.save
		c.save
		d.save
		e.save
		f.save
		g.save
		h.save
		if i.save
			redirect_to '/home/tour_url_add'
		end
	end

	def accommodation_url_add
	end

	def accommodation_complete
		a = AccommodationUrls.new
		a.accommo_name = params[:name]
		a.accommo_url = params[:url1]
	 	b = AccommodationUrls.new
		b.accommo_name = params[:name]
		b.accommo_url = params[:url2]
	 	c = AccommodationUrls.new
		c.accommo_name = params[:name]
		c.accommo_url = params[:url3]
	 	d = AccommodationUrls.new
		d.accommo_name = params[:name]
		d.accommo_url = params[:url4]
	 	e = AccommodationUrls.new
		e.accommo_name = params[:name]
		e.accommo_url = params[:url5]
	 	f = AccommodationUrls.new
		f.accommo_name = params[:name]
		f.accommo_url = params[:url6]
	 	g = AccommodationUrls.new
		g.accommo_name = params[:name]
		g.accommo_url = params[:url7]
	 	h = AccommodationUrls.new
		h.accommo_name = params[:name]
		h.accommo_url = params[:url8]
	 	i = AccommodationUrls.new
		i.accommo_name = params[:name]
		i.accommo_url = params[:url9]

		a.save
		b.save
		c.save
		d.save
		e.save
		f.save
		g.save
		h.save
		if i.save
			redirect_to '/home/accommodation_url_add'
		end
	end

  def add
  end

  def add_complete
		r = RestaurantUrl.new
		r.rest_name = params[:name]
		r.rest_url = params[:url1]
		a = RestaurantUrl.new
		a.rest_name = params[:name]
		a.rest_url = params[:url2]
		b = RestaurantUrl.new
		b.rest_name = params[:name]
		b.rest_url = params[:url3]
		c = RestaurantUrl.new
		c.rest_name = params[:name]
		c.rest_url = params[:url4]
		d = RestaurantUrl.new
		d.rest_name = params[:name]
		d.rest_url = params[:url5]
		e = RestaurantUrl.new
		e.rest_name = params[:name]
		e.rest_url = params[:url6]
		f = RestaurantUrl.new
		f.rest_name = params[:name]
		f.rest_url = params[:url7]
		g = RestaurantUrl.new
		g.rest_name = params[:name]
		g.rest_url = params[:url8]
		h = RestaurantUrl.new
		h.rest_name = params[:name]
		h.rest_url = params[:url9]

		a.save
		b.save
		c.save
		d.save	
		e.save
		f.save
		g.save
		h.save	

		if r.save
			redirect_to '/home/add' 
		end
  end
	
	def accomo_add

	end

	def accomo_complete
		a = Accommodation.new
		a.name = params[:name]
		a.longitude = params[:long]
		a.latitude = params[:lat]
		a.accomo_type = params[:accomo_type]

		if a.save
			redirect_to '/home/accomo_add'
		end
	end
 
 	def tour_add
	end

	def tour_complete
		a = Tour.new
		a.name = params[:name]
		a.longitude = params[:long]
		a.latitude = params[:lat]
		a.tour_type = params[:tour_type]

		if a.save
			redirect_to '/home/tour_add'
		end
	end

	def jeongwookgod
	end

	def jeongwook
		name = params[:name]
		url = params[:address]
		
		a = TotalImgs.new 
		a.name = name
		a.url = url
		
		if a.save
			redirect_to '/home/jeongwookgod'
		end
	end
end

