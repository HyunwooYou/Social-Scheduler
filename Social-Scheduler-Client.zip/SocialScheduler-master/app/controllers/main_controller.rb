class MainController < ApplicationController

	def my_interest
		require 'json'
		#render text: "jein" 
		#redirect_to '/'

		del = RestaurantWeight.all
		del.each do |a|
			a.destroy
		end

		del1 = AccommodationWeight.all
		del1.each do|b|
			b.destroy
		end

		del2 = TourWeight.all
		del2.each do|c|
			c.destroy
		end
		
		copy_a = Restaurant.all
		copy_a.each do |a|
			temp = RestaurantWeight.new
			temp.name = a.name
			temp.longitude = a.longitude
			temp.latitude = a.latitude
			temp.weight = a.weight
			temp.rest_type = a.rest_type
			temp.address = a.address
			temp.save
		end

		copy_b = Accommodation.all
		copy_b.each do |a|
			temp = AccommodationWeight.new
			temp.name = a.name
			temp.longitude = a.longitude
			temp.latitude = a.latitude
			temp.weight = a.weight
			temp.accommo_type = a.accomo_type
			temp.address = a.address
			temp.save
		end

		copy_c = Tour.all
		copy_c.each do |a|
			temp = TourWeight.new
			temp.name = a.name
			temp.longitude = a.longitude
			temp.latitude = a.latitude
			temp.weight = a.weight
			temp.tour_type = a.tour_type
			temp.address = a.address
			temp.save
		end
		
		#RestaurantWeight table읽어서 한식 카테고리 뽑아서 json 가중치를 적용시키기.
	  total = RestaurantWeight.all
		
		korea = total.where(rest_type:"한식")
		k_weight = params[:한식].to_f+1

    korea.each do |w|
			w.weight = w.weight*k_weight	
			w.save
		end

		cafe = total.where(rest_type:"카페")
		cafe_weight = params[:카페].to_f+1

    cafe.each do |w|
			w.weight = w.weight*cafe_weight	
			w.save
		end

		china = total.where(rest_type:"중식")
		c_weight = params[:중식].to_f+1

    china.each do |w|
			w.weight = w.weight*c_weight	
			w.save
		end

		west = total.where(rest_type:"양식")
		w_weight = params[:양식].to_f+1

    west.each do |w|
			w.weight = w.weight*w_weight	
			w.save
		end

		japan = total.where(rest_type:"일식")
		j_weight = params[:일식].to_f+1

    japan.each do |w|
			w.weight = w.weight*j_weight	
			w.save
		end

		etc = total.where(rest_type:"분식")
		etc_weight = params[:분식].to_f+1

    etc.each do |w|
			w.weight = w.weight*etc_weight	
			w.save
		end
		
		#AccommodationWeight tabl읽어서 카테고리 뽑아서 json 가중치를 적용시키기.
		total1 = AccommodationWeight.all

		hotel = total1.where(accommo_type:"호텔")
		hotel_weight = params[:호텔].to_f+1

		hotel.each do |w|
			w.weight = w.weight * hotel_weight
			w.save
		end

		resort = total1.where(accommo_type:"리조트")
		resort_weight = params[:리조트].to_f+1

		resort.each do |w|
			w.weight = w.weight * resort_weight
			w.save
		end

		pension = total1.where(accommo_type:"펜션")
		pension_weight = params[:펜션].to_f+1

		pension.each do |w|
			w.weight = w.weight * pension_weight
			w.save
		end

		#TourWeight table읽어서 마테고리 뽑아서 json가중치를 적용시키기
		total2 = TourWeight.all

		mou = total2.where(tour_type:"산")
		mou_weight = params[:산].to_f+1

		mou.each do |w|
			w.weight = w.weight * mou_weight
			w.save
		end

		island = total2.where(tour_type:"섬")
		is_weight = params[:섬].to_f+1

		island.each do |w|
			w.weight = w.weight * is_weight
			w.save
		end

		sea = total2.where(tour_type:"바다")
		sea_weight = params[:바다].to_f+1

		sea.each do |w|
			w.weight = w.weight * sea_weight
			w.save
		end
		
		rep = total2.where(tour_type:"레포츠")
		rep_weight = params[:레포츠].to_f+1

		rep.each do |w|
			w.weight = w.weight * rep_weight
			w.save
		end
		
		his = total2.where(tour_type:"역사")
		his_weight = params[:역사].to_f+1

		his.each do |w|
			w.weight = w.weight * his_weight
			w.save
		end

		cul = total2.where(tour_type:"문화")
		cul_weight = params[:문화].to_f+1

		cul.each do |w|
			w.weight = w.weight * cul_weight
			w.save
		end

		fes = total2.where(tour_type:"축제")
		fes_weight = params[:축제].to_f+1

		fes.each do |w|
			w.weight = w.weight * fes_weight
			w.save
		end

#		render json: params
		redirect_to '/'

	end

  def main_page
		@restaurants = RestaurantWeight.all.order('weight DESC')
		@plan = UserPlan.all
		@imgs = RestaurantUrl.all
  end

	def accommo_page
	  @accommodations = AccommodationWeight.all.order('weight DESC')
		@plan = UserPlan.all
		@imgs = AccommodationUrls.all
	end

	def tour_page
		@tours = TourWeight.all.order('weight DESC')
		@plan = UserPlan.all
		@imgs = TourUrls.all
	end	

  def result_page
		@user_plan = UserSelection.all
		@imgs = TotalImgs.all
		
  end

	def trend_page
		@trend = TrendSchedule.all
		@imgs = TotalImgs.all
	end
	
 	def store_plan 
		p = UserPlan.new
		p.plan_name = params[:name]
		p.plan_type = params[:type]
		p.fieldname = params[:img]
		if p.save
			a = UserPlan.last
			render json: a
		end
		#render text: params[:name] + " hi " 
		#render json: Accommodation.all
	end


	def save_result
		require 'json'

		del = UserSelection.all
		del.each do |a|
			a.destroy
		end

		del1 = UserPlan.all
		del1.each do |a|
			a.destroy
		end

		tmp = JSON.parse(params[:result])

		tmp = tmp.sort { |x,y| x["time"] <=> y["time"] } 

		tmp.each do |t|
			pu =  UserSelection.new
			pu.time = t['time']
			pu.name = t['name']
			pu.plan_type = t['type']

			if Restaurant.find_by_name(pu.name)
				pu.lat=Restaurant.find_by_name(pu.name).latitude
				pu.lng=Restaurant.find_by_name(pu.name).longitude
			end

			if Accommodation.find_by_name(pu.name)
				pu.lat=Accommodation.find_by_name(pu.name).latitude
				pu.lng=Accommodation.find_by_name(pu.name).longitude
			end

			if Tour.find_by_name(pu.name)
				pu.lat=Tour.find_by_name(pu.name).latitude
				pu.lng=Tour.find_by_name(pu.name).longitude
			end
			pu.save
		end

		redirect_to '/main/result_page'
	end

	def delete_plan
		delete_num = params[:num]
		ret = UserPlan.find(delete_num) 
		ret.destroy

		render json: { delete_id: delete_num } 
	end

	def get_images
		res_name = params[:name]
		ret = RestaurantUrl.where(rest_name: res_name)
		render json: ret
	end

	def get_images_accommo
		name = params[:name]
		ret = AccommodationUrls.where(accommo_name: name)
		render json: ret
	end	

	def get_images_tour
		name = params[:name]
		ret = TourUrls.where(tour_name: name)
		render json: ret
	end

	def before_change
		require 'json'
		
		tmp = JSON.parse(params[:result])

		tmp.each do |t|
			to = t['to']
			from = t['from']
			url = t['url']
			name = t['name']
			type = t['type']
			if UserPlan.find_by_plan_name(name)
				a = UserPlan.find_by_plan_name(name)	
				a.to =to
				a.from = from
				a.save
			else
				a = UserPlan.new
				a.to = to
				a.from = from
				a.plan_name = name
				a.fieldname =url
				a.plan_type =type
				a.save
			end
		end
		
		redirect_to '/main/accommo_page'
	end

end

