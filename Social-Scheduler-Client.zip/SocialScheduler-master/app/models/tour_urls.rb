class TourUrls < ActiveRecord::Base
end
