class TotalImgs < ActiveRecord::Base
end
