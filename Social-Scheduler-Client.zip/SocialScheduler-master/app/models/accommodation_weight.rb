class AccommodationWeight < ActiveRecord::Base
end
