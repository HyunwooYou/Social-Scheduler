class AccommodationUrls < ActiveRecord::Base
end
