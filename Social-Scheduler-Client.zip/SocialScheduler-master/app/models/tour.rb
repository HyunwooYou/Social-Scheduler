class Tour < ActiveRecord::Base
end
