class Restaurant < ActiveRecord::Base
end
