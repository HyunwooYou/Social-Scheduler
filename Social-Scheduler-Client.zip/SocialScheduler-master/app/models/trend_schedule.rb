class TrendSchedule < ActiveRecord::Base
end
