class UserSelection < ActiveRecord::Base
end
