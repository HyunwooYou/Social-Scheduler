class Accommodation < ActiveRecord::Base
end
