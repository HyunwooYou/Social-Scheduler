class Trend < ActiveRecord::Base
end
