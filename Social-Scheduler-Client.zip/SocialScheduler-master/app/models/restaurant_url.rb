class RestaurantUrl < ActiveRecord::Base
end
