class RestaurantWeight < ActiveRecord::Base
end
