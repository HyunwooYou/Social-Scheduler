class UserPlan < ActiveRecord::Base
end
