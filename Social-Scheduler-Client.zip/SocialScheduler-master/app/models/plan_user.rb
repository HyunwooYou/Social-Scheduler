class PlanUser < ActiveRecord::Base
  belongs_to :restaurant
  belongs_to :accommodation
  belongs_to :tour
end
