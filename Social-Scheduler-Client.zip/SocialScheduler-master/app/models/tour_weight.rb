class TourWeight < ActiveRecord::Base
end
