class AccommodaionWeight < ActiveRecord::Base
end
