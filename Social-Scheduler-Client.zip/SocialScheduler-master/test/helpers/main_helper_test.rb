require 'test_helper'

class MainHelperTest < ActionView::TestCase
end
