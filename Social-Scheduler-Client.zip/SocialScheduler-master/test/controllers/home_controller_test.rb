require 'test_helper'

class HomeControllerTest < ActionController::TestCase
  test "should get add" do
    get :add
    assert_response :success
  end

  test "should get add_complete" do
    get :add_complete
    assert_response :success
  end

end
