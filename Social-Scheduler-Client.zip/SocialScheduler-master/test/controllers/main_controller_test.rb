require 'test_helper'

class MainControllerTest < ActionController::TestCase
  test "should get main_page" do
    get :main_page
    assert_response :success
  end

  test "should get result_page" do
    get :result_page
    assert_response :success
  end

end
