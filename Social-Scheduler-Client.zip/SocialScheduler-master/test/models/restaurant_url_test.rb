require 'test_helper'

class RestaurantUrlTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
