require 'test_helper'

class UserPlanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
