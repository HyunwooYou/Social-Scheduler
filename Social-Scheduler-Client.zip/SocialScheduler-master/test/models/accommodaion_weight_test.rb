require 'test_helper'

class AccommodaionWeightTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
