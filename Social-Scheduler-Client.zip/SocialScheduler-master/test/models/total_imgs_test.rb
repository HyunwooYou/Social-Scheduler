require 'test_helper'

class TotalImgsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
