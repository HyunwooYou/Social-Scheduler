require 'test_helper'

class RestaurantWeightTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
