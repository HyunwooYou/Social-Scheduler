require 'test_helper'

class TrendTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
