require 'test_helper'

class TourWeightTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
