require 'test_helper'

class AccommodationUrlsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
