require 'test_helper'

class TourUrlsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
