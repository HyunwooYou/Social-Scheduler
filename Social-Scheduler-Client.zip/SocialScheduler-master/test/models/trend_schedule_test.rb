require 'test_helper'

class TrendScheduleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
