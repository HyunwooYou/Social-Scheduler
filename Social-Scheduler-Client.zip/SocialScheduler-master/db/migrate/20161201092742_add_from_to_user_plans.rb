class AddFromToUserPlans < ActiveRecord::Migration
  def change
    add_column :user_plans, :from, :string
  end
end
