class CreateTourWeights < ActiveRecord::Migration
  def change
    create_table :tour_weights do |t|
			t.string :name
			t.float :longitude
			t.float :latitude
			t.string :accommo_type
			t.float :weight
			t.string :address

      t.timestamps
    end
  end
end
