class CreateUserSelections < ActiveRecord::Migration
  def change
    create_table :user_selections do |t|
      t.string :time
      t.string :name
      t.string :plan_type
      t.float :lat
      t.float :lng

      t.timestamps
    end
  end
end
