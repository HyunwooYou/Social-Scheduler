class AddWeightToAccommodations < ActiveRecord::Migration
  def change
    add_column :accommodations, :weight, :integer
  end
end
