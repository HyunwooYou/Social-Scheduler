class CreateAccommodations < ActiveRecord::Migration
  def change
    create_table :accommodations do |t|
			t.string :name
			t.float :longitude
			t.float :latitude
			t.string :accomo_type

      t.timestamps
    end
  end
end
