class CreateRestaurantWeights < ActiveRecord::Migration
  def change
    create_table :restaurant_weights do |t|
			t.string :name
			t.float :longitude
			t.float :latitude
			t.string :rest_type
			t.float :weight

      t.timestamps
    end
  end
end
