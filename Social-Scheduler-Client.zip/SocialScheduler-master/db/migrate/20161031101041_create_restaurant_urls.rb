class CreateRestaurantUrls < ActiveRecord::Migration
  def change
    create_table :restaurant_urls do |t|
			t.string :rest_name
			t.string :rest_url

      t.timestamps
    end
  end
end
