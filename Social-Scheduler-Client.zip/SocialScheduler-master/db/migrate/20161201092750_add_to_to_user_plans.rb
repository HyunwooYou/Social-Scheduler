class AddToToUserPlans < ActiveRecord::Migration
  def change
    add_column :user_plans, :to, :string
  end
end
