class CreatePlanUsers < ActiveRecord::Migration
  def change
    create_table :plan_users do |t|
      t.string :time
      t.string :plan_type
      t.string :name

      t.references :restaurant, index: true
      t.references :accommodation, index: true
      t.references :tour, index: true

      t.timestamps
    end
  end
end
