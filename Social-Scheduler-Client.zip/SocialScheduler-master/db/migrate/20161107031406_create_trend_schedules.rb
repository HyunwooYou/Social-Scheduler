class CreateTrendSchedules < ActiveRecord::Migration
  def change
    create_table :trend_schedules do |t|
			t.string :name
			t.float  :longitude
			t.float  :latitude
			t.string :plan_type

      t.timestamps
    end
  end
end
