class FixName < ActiveRecord::Migration
  def change
		rename_column :tour_weights, :accommo_type, :tour_type
  end
end
