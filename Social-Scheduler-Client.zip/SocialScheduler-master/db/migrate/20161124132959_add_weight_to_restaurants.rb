class AddWeightToRestaurants < ActiveRecord::Migration
  def change
    add_column :restaurants, :weight, :integer
  end
end
