class CreateTourUrls < ActiveRecord::Migration
  def change
    create_table :tour_urls do |t|
			t.string :tour_name
			t.string :tour_url
      t.timestamps
    end
  end
end
