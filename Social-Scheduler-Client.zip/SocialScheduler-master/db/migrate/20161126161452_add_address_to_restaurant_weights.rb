class AddAddressToRestaurantWeights < ActiveRecord::Migration
  def change
    add_column :restaurant_weights, :address, :string
  end
end
