class AddWeightToTours < ActiveRecord::Migration
  def change
    add_column :tours, :weight, :integer
  end
end
