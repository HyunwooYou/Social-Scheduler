class AddAddressToTours < ActiveRecord::Migration
  def change
    add_column :tours, :address, :string
  end
end
