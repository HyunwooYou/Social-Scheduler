class CreateUserPlans < ActiveRecord::Migration
  def change
    create_table :user_plans do |t|
			t.string :plan_name
			t.string :plan_type

      t.timestamps
    end
  end
end
