class AddImgToUserPlans < ActiveRecord::Migration
  def change
    add_column :user_plans, :fieldname, :string
  end
end
