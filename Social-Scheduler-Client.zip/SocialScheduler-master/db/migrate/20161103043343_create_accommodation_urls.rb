class CreateAccommodationUrls < ActiveRecord::Migration
  def change
    create_table :accommodation_urls do |t|
			t.string :accommo_name
			t.string :accommo_url
      t.timestamps
    end
  end
end
