# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20161201092750) do

  create_table "accommodaion_weights", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "accommo_type"
    t.float    "weight"
    t.string   "address"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "accommodation_urls", force: true do |t|
    t.string   "accommo_name"
    t.string   "accommo_url"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "accommodation_weights", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "accommo_type"
    t.float    "weight"
    t.string   "address"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "accommodations", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "accomo_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "address"
    t.integer  "weight"
  end

  create_table "plan_users", force: true do |t|
    t.string   "time"
    t.string   "plan_type"
    t.string   "name"
    t.integer  "restaurant_id"
    t.integer  "accommodation_id"
    t.integer  "tour_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "plan_users", ["accommodation_id"], name: "index_plan_users_on_accommodation_id"
  add_index "plan_users", ["restaurant_id"], name: "index_plan_users_on_restaurant_id"
  add_index "plan_users", ["tour_id"], name: "index_plan_users_on_tour_id"

  create_table "restaurant_urls", force: true do |t|
    t.string   "rest_name"
    t.string   "rest_url"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "restaurant_weights", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "rest_type"
    t.float    "weight"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "address"
  end

  create_table "restaurants", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "rest_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "weight"
    t.string   "address"
  end

  create_table "total_imgs", force: true do |t|
    t.string   "name"
    t.string   "url"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tour_urls", force: true do |t|
    t.string   "tour_name"
    t.string   "tour_url"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tour_weights", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "tour_type"
    t.float    "weight"
    t.string   "address"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tours", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "tour_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "address"
    t.integer  "weight"
  end

  create_table "trend_schedules", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "plan_type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "trends", force: true do |t|
    t.string   "name"
    t.float    "longitude"
    t.float    "latitude"
    t.string   "type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "user_plans", force: true do |t|
    t.string   "plan_name"
    t.string   "plan_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "fieldname"
    t.string   "from"
    t.string   "to"
  end

  create_table "user_selections", force: true do |t|
    t.string   "time"
    t.string   "name"
    t.string   "plan_type"
    t.float    "lat"
    t.float    "lng"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
